@extends('layouts.default')
@push('title', get_phrase('Bootcamp Details'))
@push('meta')@endpush
@push('css')
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root {
    --navy: #0a1628;
    --navy2: #112240;
    --navy3: #1a3a6b;
    --gold: #c9a84c;
    --gold2: #e8c96d;
    --gold3: #f5e0a0;
    --cream: #faf7f2;
    --cream2: #f0ebe2;
    --cream3: #e5ddd0;
    --bc-text: #1a1208;
    --bc-text2: #3d3420;
    --muted: #6b5e45;
    --faint: #9e906e;
    --ff: 'Playfair Display', Georgia, serif;
    --fb: 'DM Sans', system-ui, sans-serif;
    --bc-border: rgba(201,168,76,0.2);
}

/* ── HERO ── */
.bc-hero { background: var(--navy); position: relative; overflow: hidden; min-height: 540px; }
.bc-hero-texture {
    position: absolute; inset: 0;
    background-image:
        repeating-linear-gradient(0deg, transparent, transparent 79px, rgba(201,168,76,.04) 79px, rgba(201,168,76,.04) 80px),
        repeating-linear-gradient(90deg, transparent, transparent 79px, rgba(201,168,76,.04) 79px, rgba(201,168,76,.04) 80px);
    pointer-events: none;
}
.bc-hero-radial  { position:absolute; top:-200px; right:-100px; width:700px; height:700px; background:radial-gradient(circle,rgba(201,168,76,.08) 0%,transparent 65%); pointer-events:none; }
.bc-hero-radial2 { position:absolute; bottom:-300px; left:-200px; width:600px; height:600px; background:radial-gradient(circle,rgba(26,58,107,.6) 0%,transparent 65%); pointer-events:none; }
.bc-hero-topline { position:absolute; top:0; left:0; right:0; height:3px; background:linear-gradient(90deg,transparent,var(--gold),var(--gold2),var(--gold),transparent); }

.bc-strip { padding:16px 0; border-bottom:1px solid rgba(201,168,76,.15); position:relative; z-index:3; }
.bc-strip-inner { display:flex; align-items:center; }
.bc-crumb { display:flex; align-items:center; gap:8px; font-size:12px; letter-spacing:.06em; text-transform:uppercase; font-family:var(--fb); }
.bc-crumb a { color:rgba(255,255,255,.35); text-decoration:none; transition:color .2s; font-weight:500; }
.bc-crumb a:hover { color:var(--gold2); }
.bc-crumb-sep { color:rgba(201,168,76,.35); font-size:10px; }
.bc-crumb-active { color:rgba(255,255,255,.7); font-weight:500; max-width:420px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

.bc-inner { position:relative; z-index:3; padding:52px 0 60px; }
.bc-layout { display:grid; grid-template-columns:1fr 340px; gap:52px; align-items:start; }

.bc-eyebrow { display:inline-flex; align-items:center; gap:9px; margin-bottom:22px; }
.bc-eyebrow-line { width:28px; height:1px; background:var(--gold); }
.bc-eyebrow-txt { font-size:11px; letter-spacing:.18em; text-transform:uppercase; color:var(--gold); font-weight:600; font-family:var(--fb); }

.bc-h1 { font-family:var(--ff); font-size:clamp(28px,3.5vw,46px); font-weight:600; color:#fff; line-height:1.08; letter-spacing:-.5px; margin-bottom:20px; }
.bc-h1 em { color:var(--gold2); font-style:normal; }

.bc-lead { font-size:15px; color:rgba(255,255,255,.45); line-height:1.85; margin-bottom:28px; max-width:520px; font-weight:300; font-family:var(--fb); }

.bc-meta-bar { display:flex; align-items:center; flex-wrap:wrap; margin-bottom:32px; padding-bottom:28px; border-bottom:1px solid rgba(201,168,76,.12); }
.bc-meta-item { display:flex; align-items:center; gap:8px; font-size:12.5px; color:rgba(255,255,255,.4); padding-right:22px; margin-right:22px; border-right:1px solid rgba(255,255,255,.08); font-family:var(--fb); }
.bc-meta-item:last-child { border-right:none; padding-right:0; margin-right:0; }
.bc-meta-avatar { width:28px; height:28px; border-radius:50%; border:1.5px solid rgba(201,168,76,.4); object-fit:cover; }
.bc-meta-link { color:rgba(255,255,255,.75); text-decoration:none; font-weight:500; transition:color .2s; }
.bc-meta-link:hover { color:var(--gold2); }
.bc-meta-icon { width:13px; height:13px; stroke:rgba(255,255,255,.4); fill:none; stroke-width:1.5; }

.bc-stats { display:grid; grid-template-columns:repeat(4,1fr); border:1px solid rgba(201,168,76,.15); border-radius:10px; overflow:hidden; background:rgba(255,255,255,.02); }
.bc-stat { padding:16px 12px; border-right:1px solid rgba(201,168,76,.12); text-align:center; }
.bc-stat:last-child { border-right:none; }
.bc-stat-n { font-family:var(--ff); font-size:26px; color:#fff; display:block; line-height:1; font-weight:600; }
.bc-stat-n span { color:var(--gold); font-size:18px; }
.bc-stat-l { display:block; margin-top:5px; font-size:10px; color:rgba(255,255,255,.28); text-transform:uppercase; letter-spacing:.12em; font-weight:500; font-family:var(--fb); }

/* Thumb card */
.bc-thumb-wrap { position:relative; }
.bc-thumb-badge { position:absolute; top:-12px; right:-12px; z-index:5; background:var(--gold); color:var(--navy); font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:6px 14px; border-radius:20px; box-shadow:0 4px 20px rgba(201,168,76,.4); font-family:var(--fb); }
.bc-thumb-card { border-radius:14px; overflow:hidden; border:1px solid rgba(201,168,76,.2); box-shadow:0 24px 60px rgba(0,0,0,.5); position:relative; }
.bc-thumb { position:relative; aspect-ratio:16/9; overflow:hidden; background:var(--navy2); }
.bc-thumb img { width:100%; height:100%; object-fit:cover; display:block; }
.bc-thumb-overlay { position:absolute; inset:0; background:linear-gradient(to top,rgba(10,22,40,.7) 0%,transparent 60%); }
.bc-play-btn { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); width:56px; height:56px; border-radius:50%; background:rgba(201,168,76,.15); border:1.5px solid rgba(201,168,76,.5); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .25s; backdrop-filter:blur(4px); }
.bc-play-btn:hover { background:var(--gold); border-color:var(--gold); transform:translate(-50%,-50%) scale(1.08); }
.bc-play-btn svg { fill:#fff; width:18px; height:18px; margin-left:3px; }
.bc-thumb-label { position:absolute; bottom:14px; left:14px; right:14px; display:flex; justify-content:space-between; align-items:center; z-index:2; }
.bc-preview-txt { font-size:11px; color:rgba(255,255,255,.6); letter-spacing:.08em; text-transform:uppercase; font-weight:500; font-family:var(--fb); }
.bc-free-badge { background:rgba(201,168,76,.2); border:1px solid rgba(201,168,76,.4); color:var(--gold2); font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:4px 12px; border-radius:20px; font-family:var(--fb); }

.bc-wave { line-height:0; position:relative; z-index:2; margin-top:-2px; }
.bc-wave svg { display:block; width:100%; }

/* ── PAGE BODY ── */
.bc-page-body { padding:40px 0 80px; background:var(--cream); }
.bc-page-layout { display:grid; grid-template-columns:1fr 310px; gap:36px; align-items:start; }

/* TABS */
.bc-tabs-nav { display:flex; border-bottom:1px solid var(--cream3); margin-bottom:28px; }
.bc-tab-btn { padding:12px 22px; font-size:13px; font-weight:500; color:var(--faint); background:none; border:none; cursor:pointer; position:relative; font-family:var(--fb); letter-spacing:.03em; transition:color .2s; border-bottom:2px solid transparent; margin-bottom:-1px; }
.bc-tab-btn:hover { color:var(--bc-text2); }
.bc-tab-btn.active { color:var(--navy); border-bottom-color:var(--gold); }

/* BOX */
.bc-box { background:#fff; border:1px solid rgba(0,0,0,.07); border-radius:16px; padding:28px; margin-bottom:20px; box-shadow:0 2px 16px rgba(0,0,0,.04); }
.bc-box-header { display:flex; align-items:center; gap:12px; margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--cream2); }
.bc-box-icon { width:36px; height:36px; border-radius:10px; background:linear-gradient(135deg,var(--navy),var(--navy3)); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.bc-box-icon svg { width:16px; height:16px; stroke:#fff; fill:none; stroke-width:1.6; }
.bc-box-title { font-family:var(--ff); font-size:21px; font-weight:600; color:var(--navy); }
.bc-box-subtitle { font-size:12px; color:var(--faint); font-weight:400; letter-spacing:.04em; text-transform:uppercase; margin-top:1px; font-family:var(--fb); }

/* Description */
.bc-description { font-size:14px; color:var(--muted); line-height:1.85; display:-webkit-box; -webkit-line-clamp:4; -webkit-box-orient:vertical; overflow:hidden; font-family:var(--fb); }
.bc-description--expanded { display:block !important; -webkit-line-clamp:unset !important; overflow:visible !important; }
.bc-see-more { display:inline-flex; align-items:center; gap:6px; margin-top:14px; font-size:13px; font-weight:500; color:var(--navy3); background:none; border:none; cursor:pointer; padding:0; font-family:var(--fb); transition:opacity .2s; }
.bc-see-more:hover { opacity:.7; }

/* Animations */
@keyframes bcFadeUp { from { opacity:0; transform:translateY(18px); } to { opacity:1; transform:translateY(0); } }
.bc-inner .bc-eyebrow { animation:bcFadeUp .6s .05s both; }
.bc-inner .bc-h1      { animation:bcFadeUp .6s .12s both; }
.bc-inner .bc-lead    { animation:bcFadeUp .6s .18s both; }
.bc-inner .bc-meta-bar { animation:bcFadeUp .6s .24s both; }
.bc-inner .bc-stats   { animation:bcFadeUp .6s .30s both; }
.bc-thumb-wrap        { animation:bcFadeUp .6s .10s both; }
</style>
@endpush

@section('content')

{{-- ── HERO ── --}}
<section class="bc-hero">
    <div class="bc-hero-texture"></div>
    <div class="bc-hero-radial"></div>
    <div class="bc-hero-radial2"></div>
    <div class="bc-hero-topline"></div>

    <div class="bc-strip">
        <div class="container bc-strip-inner">
            <div class="bc-crumb">
                <a href="{{ route('home') }}">{{ get_phrase('Home') }}</a>
                <span class="bc-crumb-sep">›</span>
                <a href="{{ route('bootcamps') }}">{{ get_phrase('bootcamp') }}</a>
                <span class="bc-crumb-sep">›</span>
                <span class="bc-crumb-active">{{ $bootcamp_details->title }}</span>
            </div>
        </div>
    </div>

    <div class="container bc-inner">
        <div class="bc-layout">
            {{-- Left: text --}}
            <div>
                <div class="bc-eyebrow">
                    <div class="bc-eyebrow-line"></div>
                    <span class="bc-eyebrow-txt">{{ get_phrase('Professional Diploma Program') }}</span>
                </div>

                <h1 class="bc-h1">{{ $bootcamp_details->title }}</h1>
                <p class="bc-lead">{{ $bootcamp_details->short_description }}</p>

                @php $user = get_user_info($bootcamp_details->user_id); @endphp
                <div class="bc-meta-bar">
                    <div class="bc-meta-item">
                        <img class="bc-meta-avatar" src="{{ get_image($user->photo) }}" alt="{{ $user->name }}">
                        <a href="{{ route('instructor.details', ['name' => slugify($user->name), 'id' => $user->id]) }}" class="bc-meta-link">{{ $user->name }}</a>
                    </div>
                    <div class="bc-meta-item">
                        <svg class="bc-meta-icon" viewBox="0 0 20 20"><circle cx="10" cy="10" r="7.5"/><path d="M10 6.5v3.75l2.25 2.25" stroke-linecap="round"/></svg>
                        {{ date('d M Y', $bootcamp_details->publish_date) }}
                    </div>
                    <div class="bc-meta-item">
                        <svg class="bc-meta-icon" viewBox="0 0 20 20"><path d="M3 5h14M3 10h10M3 15h7" stroke-linecap="round"/></svg>
                        @php $cm = count_bootcamp_modules($bootcamp_details->id); @endphp
                        {{ $cm }} {{ get_phrase($cm > 1 ? 'Modules' : 'Module') }}
                    </div>
                    <div class="bc-meta-item">
                        <svg class="bc-meta-icon" viewBox="0 0 20 20"><rect x="2" y="4" width="16" height="14" rx="2"/><path d="M2 8h16M6.5 2v3M13.5 2v3" stroke-linecap="round"/></svg>
                        @php $cc = count_bootcamp_classes($bootcamp_details->id); @endphp
                        {{ $cc }} {{ get_phrase($cc > 1 ? 'Classes' : 'Class') }}
                    </div>
                </div>

                <div class="bc-stats">
                    <div class="bc-stat">
                        <span class="bc-stat-n"><span>{{ get_phrase('Live') }}</span></span>
                        <span class="bc-stat-l">{{ get_phrase('Sessions') }}</span>
                    </div>
                    <div class="bc-stat">
                        <span class="bc-stat-n">{{ $cm }}<span>+</span></span>
                        <span class="bc-stat-l">{{ get_phrase('Modules') }}</span>
                    </div>
                    <div class="bc-stat">
                        <span class="bc-stat-n">{{ total_enroll($bootcamp_details->id) }}</span>
                        <span class="bc-stat-l">{{ get_phrase('Students') }}</span>
                    </div>
                    <div class="bc-stat">
                        <span class="bc-stat-n">100<span>%</span></span>
                        <span class="bc-stat-l">{{ get_phrase('Certified') }}</span>
                    </div>
                </div>
            </div>

            {{-- Right: thumbnail --}}
            <div class="bc-thumb-wrap">
                @if($bootcamp_details->is_paid)
                    <div class="bc-thumb-badge">● {{ get_phrase('Enrolling Now') }}</div>
                @else
                    <div class="bc-thumb-badge">● {{ get_phrase('Free') }}</div>
                @endif
                <div class="bc-thumb-card">
                    <div class="bc-thumb">
                        <img src="{{ get_image($bootcamp_details->thumbnail) }}" alt="{{ $bootcamp_details->title }}">
                        <div class="bc-thumb-overlay"></div>
                        @if($bootcamp_details->preview)
                            <button class="bc-play-btn" data-bs-toggle="modal" data-bs-target="#previewModal">
                                <svg viewBox="0 0 24 24"><polygon points="5,3 19,12 5,21"/></svg>
                            </button>
                        @endif
                        <div class="bc-thumb-label">
                            <span class="bc-preview-txt">▶ {{ get_phrase('Watch Preview') }}</span>
                            @if(!$bootcamp_details->is_paid)
                                <span class="bc-free-badge">{{ get_phrase('Free') }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bc-wave">
        <svg viewBox="0 0 1440 50" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,50 C240,12 480,46 720,28 C960,10 1200,44 1440,22 L1440,50 Z" fill="#faf7f2"/>
        </svg>
    </div>
</section>

{{-- ── PREVIEW MODAL ── --}}
<div class="modal eModal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="g-title">{{ ucfirst($bootcamp_details->title) }}</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <video width="100%" height="440" id="bcVideoPlayer" playsinline controls>
                    <source src="{{ asset($bootcamp_details->preview) }}" type="video/mp4">
                </video>
            </div>
        </div>
    </div>
</div>

{{-- ── BODY ── --}}
<div class="bc-page-body">
    <div class="container">
        <div class="bc-page-layout">
            {{-- Main content --}}
            <div>
                <div class="bc-tabs-nav" id="bc-tabs-nav">
                    <button class="bc-tab-btn active" data-target="bc-overview">{{ get_phrase('Overview') }}</button>
                    <button class="bc-tab-btn" data-target="bc-content">{{ get_phrase('Course Content') }}</button>
                    <button class="bc-tab-btn" data-target="bc-details">{{ get_phrase('Details') }}</button>
                    <button class="bc-tab-btn" data-target="bc-instructor">{{ get_phrase('Instructor') }}</button>
                </div>

                <div id="bc-overview" class="bc-tab-panel">
                    @include('frontend.default.bootcamp.overview_area')
                </div>
                <div id="bc-content" class="bc-tab-panel" style="display:none">
                    @include('frontend.default.bootcamp.content_area')
                </div>
                <div id="bc-details" class="bc-tab-panel" style="display:none">
                    @include('frontend.default.bootcamp.requirement_outcome_area')
                </div>
                <div id="bc-instructor" class="bc-tab-panel" style="display:none">
                    @include('frontend.default.bootcamp.instructor_area')
                </div>
            </div>

            {{-- Sidebar --}}
            <div>
                @include('frontend.default.bootcamp.pricing_card')
            </div>
        </div>
    </div>
</div>
@endsection

@push('js')
<script>
(function(){
    // Tabs
    document.querySelectorAll('.bc-tab-btn').forEach(function(btn){
        btn.addEventListener('click', function(){
            document.querySelectorAll('.bc-tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.bc-tab-panel').forEach(p => p.style.display = 'none');
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).style.display = 'block';
        });
    });
    // Video modal pause
    var vm = document.getElementById('previewModal');
    if(vm) vm.addEventListener('hidden.bs.modal', function(){
        var v = document.getElementById('bcVideoPlayer');
        if(v) v.pause();
    });
    // See more
    var smBtn = document.getElementById('bc-see-more');
    if(smBtn) smBtn.addEventListener('click', function(e){
        e.preventDefault();
        var desc = document.querySelector('.bc-description');
        if(!desc) return;
        var open = desc.classList.toggle('bc-description--expanded');
        smBtn.innerHTML = open
            ? '{{ get_phrase("See less") }} <svg width="12" height="12" viewBox="0 0 20 20" fill="none" style="stroke:currentColor;stroke-width:2;display:inline-block;vertical-align:middle"><path d="M15 12l-5-5-5 5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            : '{{ get_phrase("See more") }} <svg width="12" height="12" viewBox="0 0 20 20" fill="none" style="stroke:currentColor;stroke-width:2;display:inline-block;vertical-align:middle"><path d="M5 8l5 5 5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    });
})();
</script>
@endpush