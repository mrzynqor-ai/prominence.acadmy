{{-- filter.blade.php --}}
@php
    $categories = App\Models\BootcampCategory::get();
    $active_category = request()->route()->parameter('category');
    $route_queries = request()->query();
    $route_queries = collect($route_queries)->except('page')->all();
@endphp

<style>
/* ── SIDEBAR  pflt__ prefix ── */
.pflt {
    font-family: 'DM Sans', system-ui, sans-serif;
    display: flex; flex-direction: column; gap: 16px;
}

/* card shell */
.pflt__card {
    background: #fff;
    border: 1px solid #e0e4f8;
    border-radius: 16px;
    overflow: hidden;
}

/* card header */
.pflt__head {
    display: flex; align-items: center; justify-content: space-between;
    padding: 15px 18px 13px;
    border-bottom: 1px solid #f0f2fc;
}
.pflt__head-left { display: flex; align-items: center; gap: 10px; }
.pflt__head-icon {
    width: 30px; height: 30px; border-radius: 8px;
    background: #2f57ef;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.pflt__head-icon svg { width: 13px; height: 13px; stroke: #fff; fill: none; stroke-width: 1.8; }
.pflt__head-title {
    font-size: 12px; font-weight: 600;
    color: #0a0f2e; letter-spacing: .04em;
    text-transform: uppercase;
}
.pflt__head-clear {
    font-size: 11px; color: #9aa3c8; text-decoration: none;
    font-weight: 400; transition: color .2s;
    background: none; border: none; cursor: pointer; padding: 0;
    font-family: 'DM Sans', system-ui, sans-serif;
}
.pflt__head-clear:hover { color: #2f57ef; }

/* search */
.pflt__search { padding: 14px 14px 16px; }
.pflt__search-wrap { position: relative; }
.pflt__search-input {
    width: 100%;
    padding: 10px 40px 10px 14px;
    background: #f8f9ff; border: 1.5px solid #e0e4f8;
    border-radius: 10px; font-size: 13px; font-weight: 400;
    font-family: 'DM Sans', system-ui, sans-serif;
    color: #0a0f2e; outline: none;
    transition: border-color .2s, background .2s;
}
.pflt__search-input:focus { border-color: #2f57ef; background: #fff; }
.pflt__search-input::placeholder { color: #b0b8d8; }
.pflt__search-btn {
    position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: #b0b8d8; display: flex; padding: 0;
    transition: color .2s;
}
.pflt__search-btn:hover { color: #2f57ef; }

/* category list */
.pflt__cats {
    padding: 8px 10px 14px;
    list-style: none; margin: 0;
    display: flex; flex-direction: column; gap: 1px;
}
.pflt__cat a {
    display: flex; justify-content: space-between; align-items: center;
    padding: 9px 10px; border-radius: 10px;
    font-size: 13px; color: #1e2755; text-decoration: none;
    transition: background .15s, color .15s;
}
.pflt__cat a:hover { background: #f8f9ff; color: #2f57ef; }
.pflt__cat--active a {
    background: #eef1fd; color: #2f57ef;
    font-weight: 500;
}
.pflt__cat-count {
    font-size: 11px; background: #f0f2fc; color: #9aa3c8;
    padding: 2px 8px; border-radius: 20px; flex-shrink: 0;
    transition: background .15s, color .15s;
}
.pflt__cat--active .pflt__cat-count {
    background: #dbe1fc; color: #2f57ef;
}

/* show more */
.pflt__more-wrap { overflow: hidden; transition: max-height .3s ease; max-height: 9999px; }
.pflt__more-wrap.pflt--collapsed { max-height: 240px; }
.pflt__more-btn {
    display: flex; align-items: center; justify-content: center; gap: 6px;
    width: 100%; padding: 10px 16px;
    background: none; border: none; border-top: 1px solid #f0f2fc;
    font-size: 12px; font-weight: 500; color: #2f57ef;
    cursor: pointer; font-family: 'DM Sans', system-ui, sans-serif;
    transition: background .15s;
}
.pflt__more-btn:hover { background: #f8f9ff; }
.pflt__more-icon {
    display: inline-block; font-style: normal;
    font-size: 13px; transition: transform .25s;
    color: #2f57ef;
}
.pflt__more-btn.pflt--open .pflt__more-icon { transform: rotate(180deg); }

/* options */
.pflt__options {
    padding: 8px 10px 14px;
    display: flex; flex-direction: column; gap: 1px;
}
.pflt__opt {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 10px; border-radius: 10px;
    font-size: 13px; color: #1e2755; cursor: pointer;
    transition: background .15s; user-select: none;
}
.pflt__opt:hover { background: #f8f9ff; }
.pflt__opt input { accent-color: #2f57ef; width: 15px; height: 15px; cursor: pointer; flex-shrink: 0; }
.pflt__opt-label { flex: 1; }
.pflt__opt-badge {
    font-size: 11px; background: #eef1fd; color: #6180f4;
    padding: 2px 8px; border-radius: 20px;
    font-weight: 500;
}

/* section divider */
.pflt__section-lbl {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 18px 4px;
    font-size: 10px; font-weight: 600;
    color: #b0b8d8; letter-spacing: .08em; text-transform: uppercase;
}
.pflt__section-lbl::after {
    content: ''; flex: 1; height: 1px; background: #f0f2fc;
}

/* range slider */
.pflt__range-wrap { padding: 6px 18px 18px; }
.pflt__range {
    -webkit-appearance: none; width: 100%; height: 3px;
    border-radius: 3px; background: #dbe1fc; outline: none;
    cursor: pointer;
}
.pflt__range::-webkit-slider-thumb {
    -webkit-appearance: none; width: 16px; height: 16px;
    border-radius: 50%; background: #2f57ef;
    border: 2px solid #fff;
    box-shadow: 0 0 0 2px rgba(47,87,239,.2);
    cursor: pointer;
}
.pflt__range-vals {
    display: flex; justify-content: space-between;
    font-size: 11px; color: #9aa3c8; margin-top: 10px;
}
.pflt__range-vals span { font-weight: 500; color: #2f57ef; }

/* active filter chips */
.pflt__active { padding: 0 14px 14px; display: flex; flex-wrap: wrap; gap: 6px; }
.pflt__chip {
    display: flex; align-items: center; gap: 6px;
    font-size: 11px; font-weight: 500; color: #2f57ef;
    background: #eef1fd; border: 1px solid #dbe1fc;
    padding: 4px 10px; border-radius: 20px;
}
.pflt__chip-x {
    background: none; border: none; cursor: pointer;
    color: #9aa3c8; font-size: 12px; padding: 0;
    line-height: 1; transition: color .15s;
}
.pflt__chip-x:hover { color: #2f57ef; }
</style>

<div class="pflt">

    {{-- Search --}}
    <div class="pflt__card">
        <form action="{{ route('bootcamps', $active_category) }}" method="get">
            <div class="pflt__head">
                <div class="pflt__head-left">
                    <div class="pflt__head-icon">
                        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4" stroke-linecap="round"/></svg>
                    </div>
                    <span class="pflt__head-title">{{ get_phrase('Search') }}</span>
                </div>
            </div>
            <div class="pflt__search">
                <div class="pflt__search-wrap">
                    <input class="pflt__search-input" type="text" name="search"
                        placeholder="{{ get_phrase('Search programs...') }}"
                        value="{{ request('search') }}">
                    <button type="submit" class="pflt__search-btn">
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                            <circle cx="8.5" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.6"/>
                            <path d="M13 13l3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
        </form>
    </div>

    {{-- Active filters (shown conditionally) --}}
    @if(request('search') || $active_category)
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon" style="background:#eef1fd;">
                    <svg viewBox="0 0 24 24" style="stroke:#2f57ef"><path d="M4 6h16M7 12h10M10 18h4" stroke-linecap="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Active filters') }}</span>
            </div>
            <a href="{{ route('bootcamps') }}" class="pflt__head-clear">{{ get_phrase('Clear all') }}</a>
        </div>
        <div class="pflt__active">
            @if(request('search'))
                <div class="pflt__chip">
                    "{{ request('search') }}"
                    <a href="{{ route('bootcamps', $active_category) }}"><button class="pflt__chip-x" type="button">✕</button></a>
                </div>
            @endif
            @if($active_category)
                <div class="pflt__chip">
                    {{ $active_category }}
                    <a href="{{ route('bootcamps') }}"><button class="pflt__chip-x" type="button">✕</button></a>
                </div>
            @endif
        </div>
    </div>
    @endif

    {{-- Categories --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h6" stroke-linecap="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Categories') }}</span>
            </div>
        </div>
        <div class="pflt__more-wrap pflt--collapsed" id="pflt-cat-wrap">
            <ul class="pflt__cats">
                @foreach ($categories as $category)
                    @php $route_queries['category'] = $category->slug; @endphp
                    <li class="pflt__cat {{ $category->slug == $active_category ? 'pflt__cat--active' : '' }}">
                        <a href="{{ route('bootcamps', $route_queries) }}">
                            <span>{{ $category->title }}</span>
                            <span class="pflt__cat-count">{{ count_bootcamps_by_category($category->id) }}</span>
                        </a>
                    </li>
                @endforeach
            </ul>
        </div>
        <button class="pflt__more-btn" id="pflt-more-btn" type="button">
            <em class="pflt__more-icon">⌄</em>
            <span id="pflt-more-lbl">{{ get_phrase('Show more') }}</span>
        </button>
    </div>

    {{-- Price --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" stroke-linecap="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Price') }}</span>
            </div>
        </div>
        <div class="pflt__options">
            <label class="pflt__opt">
                <input type="radio" name="pflt_price" checked>
                <span class="pflt__opt-label">{{ get_phrase('All programs') }}</span>
            </label>
            <label class="pflt__opt">
                <input type="radio" name="pflt_price">
                <span class="pflt__opt-label">{{ get_phrase('Free') }}</span>
                <span class="pflt__opt-badge">{{ get_phrase('No cost') }}</span>
            </label>
            <label class="pflt__opt">
                <input type="radio" name="pflt_price">
                <span class="pflt__opt-label">{{ get_phrase('Paid') }}</span>
            </label>
        </div>
    </div>

    {{-- Level --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><path d="M2 20h4V10H2v10zM10 20h4V4h-4v16zM18 20h4v-6h-4v6z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Level') }}</span>
            </div>
        </div>
        <div class="pflt__options">
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('Beginner') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('Intermediate') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('Advanced') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('All levels') }}</span></label>
        </div>
    </div>

    {{-- Duration --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3" stroke-linecap="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Duration') }}</span>
            </div>
        </div>
        <div class="pflt__options">
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('Under 4 weeks') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('1–3 months') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('3–6 months') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('6+ months') }}</span></label>
        </div>
    </div>

    {{-- Language --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 3c-4 4-4 14 0 18M12 3c4 4 4 14 0 18M3 12h18" stroke-linecap="round"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Language') }}</span>
            </div>
        </div>
        <div class="pflt__options">
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('Arabic') }}</span><span class="pflt__opt-badge">عربي</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('English') }}</span></label>
            <label class="pflt__opt"><input type="checkbox"><span class="pflt__opt-label">{{ get_phrase('French') }}</span></label>
        </div>
    </div>

    {{-- Rating --}}
    <div class="pflt__card">
        <div class="pflt__head">
            <div class="pflt__head-left">
                <div class="pflt__head-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 2l3.5 7.5 8 1.1-5.8 5.6 1.4 8L12 20.5l-7.1 3.7 1.4-8L.6 10.6l8-1.1z"/></svg>
                </div>
                <span class="pflt__head-title">{{ get_phrase('Rating') }}</span>
            </div>
        </div>
        <div class="pflt__options">
            @foreach ([4.5, 4.0, 3.5, 3.0] as $r)
            <label class="pflt__opt">
                <input type="radio" name="pflt_rating">
                <span class="pflt__opt-label" style="display:flex;align-items:center;gap:5px;">
                    <span style="color:#d4a843;font-size:13px;">★★★★</span>
                    {{ $r }}{{ get_phrase('+') }}
                </span>
            </label>
            @endforeach
        </div>
    </div>

</div>

@push('js')
<script>
(function(){
    var btn  = document.getElementById('pflt-more-btn');
    var wrap = document.getElementById('pflt-cat-wrap');
    var lbl  = document.getElementById('pflt-more-lbl');
    if (!btn) return;
    btn.addEventListener('click', function(){
        var open = btn.classList.toggle('pflt--open');
        wrap.classList.toggle('pflt--collapsed', !open);
        lbl.textContent = open ? '{{ get_phrase('Show less') }}' : '{{ get_phrase('Show more') }}';
    });
    document.querySelectorAll('input[name="pflt_price"]').forEach(function(r){
        r.addEventListener('change', function(){
            var f = document.querySelector('.pflt form');
            if (f) f.submit();
        });
    });
})();
</script>
@endpush