{{-- index.blade.php --}}
@extends('layouts.default')
@push('title', get_phrase('Bootcamps'))
@push('meta')@endpush
@push('css')
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">

<style>
/* ── TOKENS ── */
:root {
    --u-blue:       #2f57ef;
    --u-blue-dk:    #1e3bbf;
    --u-blue-xdk:   #0f2080;
    --u-blue-lt:    #6180f4;
    --u-blue-pale:  #eef1fd;
    --u-blue-mist:  #dbe1fc;
    --u-white:      #ffffff;
    --u-off:        #f4f6ff;
    --u-ink:        #0a0f2e;
    --u-ink2:       #1e2755;
    --u-muted:      #5a6490;
    --u-faint:      #9aa3c8;
    --u-border:     #e0e4f8;
    --u-border-dk:  #c5ccef;
    --u-gold:       #d4a843;
    --u-green:      #1a7a4a;
    --u-ff-display: 'Cormorant Garamond', Georgia, serif;
    --u-ff-body:    'DM Sans', system-ui, sans-serif;
    --u-r:          10px;
    --u-r-lg:       18px;
    --u-r-xl:       26px;
    --u-shadow:     0 2px 20px rgba(47,87,239,.08), 0 1px 4px rgba(47,87,239,.04);
    --u-shadow-h:   0 28px 64px rgba(47,87,239,.14), 0 8px 20px rgba(47,87,239,.07);
}

/* ── BASE ── */
.upage { font-family: var(--u-ff-body); background: var(--u-off); color: var(--u-ink); }

/* ── HERO ── */
.uhero {
    background: linear-gradient(135deg, var(--u-blue-xdk) 0%, var(--u-blue-dk) 45%, var(--u-blue) 100%);
    position: relative; overflow: hidden;
}

.uhero__decor { position: absolute; inset: 0; pointer-events: none; }

.uhero__decor-lines {
    position: absolute; inset: 0;
    background-image: repeating-linear-gradient(
        -55deg, transparent, transparent 36px,
        rgba(255,255,255,.018) 36px, rgba(255,255,255,.018) 37px
    );
}

.uhero__decor-arc {
    position: absolute; top: -200px; right: -200px;
    width: 600px; height: 600px; border-radius: 50%;
    border: 60px solid rgba(255,255,255,.03);
}
.uhero__decor-arc2 {
    position: absolute; top: -100px; right: -100px;
    width: 420px; height: 420px; border-radius: 50%;
    border: 1px solid rgba(255,255,255,.08);
}
.uhero__decor-dot {
    position: absolute; bottom: 40px; left: -80px;
    width: 380px; height: 380px; border-radius: 50%;
    border: 1px solid rgba(255,255,255,.05);
}

.uhero__seal {
    position: absolute; top: 50%; right: 7%; transform: translateY(-50%);
    width: 340px; height: 340px; opacity: .035;
    display: flex; align-items: center; justify-content: center;
}
.uhero__seal svg { width: 100%; height: 100%; }

/* strip */
.uhero__strip {
    background: rgba(0,0,0,.25);
    padding: 10px 0;
    position: relative; z-index: 4;
    border-bottom: 1px solid rgba(255,255,255,.07);
}
.uhero__strip-inner { display: flex; align-items: center; justify-content: space-between; }
.uhero__crumb { display: flex; align-items: center; gap: 8px; }
.uhero__crumb a { color: rgba(255,255,255,.45); font-size: 12px; font-weight: 400; text-decoration: none; transition: color .2s; }
.uhero__crumb a:hover { color: var(--u-white); }
.uhero__crumb-sep { color: rgba(255,255,255,.2); font-size: 11px; }
.uhero__crumb-active { color: rgba(255,255,255,.85); font-size: 12px; font-weight: 500; }
.uhero__strip-badge {
    display: flex; align-items: center; gap: 7px;
    font-size: 11px; font-weight: 500; color: rgba(255,255,255,.4);
    letter-spacing: .05em;
}
.uhero__strip-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--u-gold); }

/* hero inner */
.uhero__inner {
    position: relative; z-index: 3;
    padding: 5.5rem 0 4rem;
}
.uhero__eyebrow {
    display: inline-flex; align-items: center; gap: 10px;
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.11);
    border-radius: 30px;
    padding: 6px 18px 6px 8px;
    margin-bottom: 28px;
}
.uhero__eyebrow-dot {
    width: 24px; height: 24px; border-radius: 50%;
    background: var(--u-gold);
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.uhero__eyebrow-dot svg { width: 11px; height: 11px; stroke: #fff; fill: none; stroke-width: 2; }
.uhero__eyebrow-text { color: rgba(255,255,255,.7); font-size: 11px; font-weight: 500; letter-spacing: .1em; text-transform: uppercase; }

.uhero__h1 {
    font-family: var(--u-ff-display);
    font-size: clamp(40px, 5.5vw, 62px);
    font-weight: 600; line-height: 1.07;
    color: var(--u-white);
    letter-spacing: -.4px; margin-bottom: 18px;
}
.uhero__h1 em { font-style: italic; color: rgba(255,255,255,.42); }
.uhero__h1-line { display: block; }
.uhero__h1-accent { color: var(--u-gold); }

.uhero__lead {
    color: rgba(255,255,255,.45);
    font-size: 15px; line-height: 1.8; font-weight: 300;
    max-width: 460px; margin-bottom: 40px;
}

/* stats bar */
.uhero__statsbar {
    display: inline-flex;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 16px;
    overflow: hidden;
    background: rgba(255,255,255,.05);
    backdrop-filter: blur(12px);
    margin-bottom: 44px;
}
.uhero__stat {
    padding: 18px 34px;
    border-right: 1px solid rgba(255,255,255,.07);
    text-align: center;
}
.uhero__stat:last-child { border-right: none; }
.uhero__stat-n {
    font-family: var(--u-ff-display);
    font-size: 30px; font-weight: 600;
    color: var(--u-white); line-height: 1; display: block;
}
.uhero__stat-n span { color: var(--u-gold); }
.uhero__stat-l {
    display: block; margin-top: 5px;
    font-size: 10px; color: rgba(255,255,255,.3);
    text-transform: uppercase; letter-spacing: .12em;
}

/* trust */
.uhero__trust { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
.uhero__trust-item {
    display: flex; align-items: center; gap: 8px;
    color: rgba(255,255,255,.4); font-size: 12px; font-weight: 400;
}
.uhero__trust-icon { width: 14px; height: 14px; stroke: rgba(255,255,255,.25); fill: none; stroke-width: 1.5; flex-shrink: 0; }
.uhero__trust-divider { width: 1px; height: 14px; background: rgba(255,255,255,.1); }

.uhero__wave { position: relative; z-index: 3; line-height: 0; }

/* ── FEATURED CATEGORIES ── */
.ufeat {
    background: var(--u-white);
    border-bottom: 1px solid var(--u-border);
}
.ufeat__inner {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    border-left: 1px solid var(--u-border);
}
.ufeat__item {
    display: flex; align-items: center; gap: 14px;
    padding: 20px 24px;
    border-right: 1px solid var(--u-border);
    text-decoration: none;
    transition: background .2s;
    position: relative;
}
.ufeat__item:hover { background: var(--u-blue-pale); }
.ufeat__item::after {
    content: '';
    position: absolute; bottom: 0; left: 0; right: 0; height: 2px;
    background: var(--u-blue);
    transform: scaleX(0); transition: transform .22s;
}
.ufeat__item:hover::after { transform: scaleX(1); }
.ufeat__icon {
    width: 40px; height: 40px; border-radius: 11px; flex-shrink: 0;
    background: var(--u-blue-pale);
    display: flex; align-items: center; justify-content: center;
}
.ufeat__icon svg { width: 17px; height: 17px; stroke: var(--u-blue); fill: none; stroke-width: 1.5; }
.ufeat__name { font-size: 13px; font-weight: 500; color: var(--u-ink); margin-bottom: 2px; }
.ufeat__count { font-size: 11px; color: var(--u-faint); }

/* ── BODY ── */
.ubody { padding: 2.75rem 0 5.5rem; }
.ulayout {
    display: grid; grid-template-columns: 268px 1fr;
    gap: 32px; align-items: start;
}

/* topbar */
.u-topbar {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 22px; padding-bottom: 16px;
    border-bottom: 2px solid var(--u-border);
}
.u-topbar__left { display: flex; align-items: baseline; gap: 8px; }
.u-topbar__num {
    font-family: var(--u-ff-display);
    font-size: 26px; font-weight: 600; color: var(--u-blue);
}
.u-topbar__lbl { font-size: 13px; color: var(--u-muted); }
.u-topbar__right { display: flex; align-items: center; gap: 10px; }
.u-sort-lbl { font-size: 12px; color: var(--u-muted); }
.u-sort {
    padding: 9px 14px; border: 1px solid var(--u-border);
    border-radius: var(--u-r); font-size: 13px;
    background: var(--u-white); color: var(--u-ink);
    font-family: var(--u-ff-body); font-weight: 400;
    outline: none; cursor: pointer; transition: border-color .2s;
}
.u-sort:focus { border-color: var(--u-blue); }

.u-view-toggle { display: flex; gap: 4px; }
.u-view-btn {
    width: 34px; height: 34px; border-radius: 8px;
    border: 1px solid var(--u-border);
    background: var(--u-white);
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; transition: all .18s;
    color: var(--u-faint);
}
.u-view-btn.active, .u-view-btn:hover {
    background: var(--u-blue); color: var(--u-white); border-color: var(--u-blue);
}
.u-view-btn svg { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 1.5; }

.ugrid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(285px, 1fr));
    gap: 22px;
}

/* pagination */
.u-pages { margin-top: 3rem; display: flex; justify-content: center; }
.u-pages .page-link {
    border-radius: var(--u-r) !important;
    border: 1px solid var(--u-border);
    color: var(--u-ink); font-family: var(--u-ff-body);
    font-size: 13px; font-weight: 500;
    padding: 8px 14px; transition: all .2s;
}
.u-pages .page-link:hover { background: var(--u-blue); color: var(--u-white); border-color: var(--u-blue); }
.u-pages .page-item.active .page-link { background: var(--u-blue); color: var(--u-white); border-color: var(--u-blue); }

/* empty state */
.u-empty { text-align: center; padding: 4rem 2rem; grid-column: 1 / -1; }
.u-empty__icon {
    width: 56px; height: 56px; border-radius: 16px;
    background: var(--u-blue-pale); margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
}
.u-empty__icon svg { width: 24px; height: 24px; stroke: var(--u-blue); fill: none; stroke-width: 1.5; }
.u-empty h3 { font-family: var(--u-ff-display); font-size: 22px; font-weight: 600; color: var(--u-ink); margin-bottom: 8px; }
.u-empty p { font-size: 14px; color: var(--u-muted); }
</style>
@endpush

@section('content')
<div class="upage">

    {{-- ── HERO ── --}}
    <section class="uhero">
        <div class="uhero__decor">
            <div class="uhero__decor-lines"></div>
            <div class="uhero__decor-arc"></div>
            <div class="uhero__decor-arc2"></div>
            <div class="uhero__decor-dot"></div>
            {{-- University seal watermark --}}
            <div class="uhero__seal">
                <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="100" cy="100" r="96" stroke="white" stroke-width="1.5"/>
                    <circle cx="100" cy="100" r="80" stroke="white" stroke-width="1"/>
                    <circle cx="100" cy="100" r="64" stroke="white" stroke-width="1"/>
                    <path d="M100 36 L114 78 L158 78 L124 103 L136 146 L100 121 L64 146 L76 103 L42 78 L86 78 Z" stroke="white" stroke-width="1.5" fill="none"/>
                    <circle cx="100" cy="100" r="6" fill="white"/>
                </svg>
            </div>
        </div>

        {{-- strip --}}
        <div class="uhero__strip">
            <div class="container uhero__strip-inner">
                <div class="uhero__crumb">
                    <a href="{{ url('/') }}">{{ get_phrase('Home') }}</a>
                    <span class="uhero__crumb-sep">›</span>
                    <span class="uhero__crumb-active">{{ get_phrase('bootcamp') }}</span>
                </div>
                <div class="uhero__strip-badge">
                    <span class="uhero__strip-dot"></span>
                    {{ get_phrase('Professionally Accredited Programs') }}
                </div>
            </div>
        </div>

        {{-- main --}}
        <div class="container uhero__inner">
            <div class="uhero__eyebrow">
                <div class="uhero__eyebrow-dot">
                    <svg viewBox="0 0 24 24"><path d="M12 2l3.5 7 7.5 1-5.5 5.5 1.5 7.5L12 20l-7 3.5 1.5-7.5L1 10.5l7.5-1z"/></svg>
                </div>
                <span class="uhero__eyebrow-text">{{ get_phrase('Academic Excellence Since 2010') }}</span>
            </div>

            <!--<h1 class="uhero__h1">-->
            <!--    <span class="uhero__h1-line">{{ get_phrase('Professional') }}</span>-->
            <!--    <span class="uhero__h1-line"><em>{{ get_phrase('Diplomas') }}</em> <span class="uhero__h1-accent">&amp;</span></span>-->
            <!--    <span class="uhero__h1-line">{{ get_phrase('Bootcamps') }}</span>-->
            <!--</h1>-->

            <p class="uhero__lead">
                {{ get_phrase('Industry-recognized programs crafted by world-class faculty. Earn credentials that open doors at top employers globally.') }}
            </p>

            <div class="uhero__statsbar">
                <div class="uhero__stat">
                    <span class="uhero__stat-n">{{ $bootcamps->total() }}<span>+</span></span>
                    <span class="uhero__stat-l">{{ get_phrase('Programs') }}</span>
                </div>
                <div class="uhero__stat">
                    <span class="uhero__stat-n">100<span>%</span></span>
                    <span class="uhero__stat-l">{{ get_phrase('Certified') }}</span>
                </div>
                <div class="uhero__stat">
                    <span class="uhero__stat-n"><span>Live</span></span>
                    <span class="uhero__stat-l">{{ get_phrase('Sessions') }}</span>
                </div>
                <div class="uhero__stat">
                    <span class="uhero__stat-n">50<span>k+</span></span>
                    <span class="uhero__stat-l">{{ get_phrase('Alumni') }}</span>
                </div>
            </div>

            <div class="uhero__trust">
                <div class="uhero__trust-item">
                    <svg class="uhero__trust-icon" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    {{ get_phrase('Internationally Accredited') }}
                </div>
                <div class="uhero__trust-divider"></div>
                <div class="uhero__trust-item">
                    <svg class="uhero__trust-icon" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>
                    {{ get_phrase('Expert Instructors') }}
                </div>
                <div class="uhero__trust-divider"></div>
                <div class="uhero__trust-item">
                    <svg class="uhero__trust-icon" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    {{ get_phrase('Live Online Classes') }}
                </div>
                <div class="uhero__trust-divider"></div>
                <div class="uhero__trust-item">
                    <svg class="uhero__trust-icon" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
                    {{ get_phrase('Satisfaction Guaranteed') }}
                </div>
            </div>
        </div>

        <div class="uhero__wave">
            <svg viewBox="0 0 1440 56" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" style="display:block;width:100%;height:56px;background:var(--u-blue)">
                <path d="M0,56 C180,14 360,52 540,28 C720,4 900,48 1080,30 C1260,12 1380,46 1440,24 L1440,56 Z" fill="#f8f9ff"/>
            </svg>
        </div>
    </section>

    {{-- ── FEATURED CATEGORIES STRIP ── --}}
    <div class="ufeat">
        <div class="ufeat__inner" style="max-width:1200px;margin:0 auto;">
            <a href="{{ route('bootcamps', 'data-science') }}" class="ufeat__item">
                <div class="ufeat__icon">
                    <svg viewBox="0 0 24 24"><path d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18"/></svg>
                </div>
                <div>
                    <div class="ufeat__name">{{ get_phrase('Data Science') }}</div>
                    <div class="ufeat__count">12 {{ get_phrase('programs') }}</div>
                </div>
            </a>
            <a href="{{ route('bootcamps', 'web-development') }}" class="ufeat__item">
                <div class="ufeat__icon">
                    <svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                </div>
                <div>
                    <div class="ufeat__name">{{ get_phrase('Web Development') }}</div>
                    <div class="ufeat__count">9 {{ get_phrase('programs') }}</div>
                </div>
            </a>
            <a href="{{ route('bootcamps', 'cybersecurity') }}" class="ufeat__item">
                <div class="ufeat__icon">
                    <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <div>
                    <div class="ufeat__name">{{ get_phrase('Cybersecurity') }}</div>
                    <div class="ufeat__count">6 {{ get_phrase('programs') }}</div>
                </div>
            </a>
            <a href="{{ route('bootcamps', 'business') }}" class="ufeat__item">
                <div class="ufeat__icon">
                    <svg viewBox="0 0 24 24"><path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2zM16 3H8v4h8V3z"/></svg>
                </div>
                <div>
                    <div class="ufeat__name">{{ get_phrase('Business & MBA') }}</div>
                    <div class="ufeat__count">14 {{ get_phrase('programs') }}</div>
                </div>
            </a>
        </div>
    </div>

    {{-- ── BODY ── --}}
    <div class="ubody">
        <div class="container">
            <div class="ulayout">
                <aside>@include('frontend.default.bootcamp.filter')</aside>
                <div>
                    <div class="u-topbar">
                        <div class="u-topbar__left">
                            <span class="u-topbar__num">{{ $bootcamps->total() }}</span>
                            <span class="u-topbar__lbl">{{ get_phrase('programs available') }}</span>
                        </div>
                        <div class="u-topbar__right">
                            <span class="u-sort-lbl">{{ get_phrase('Sort by') }}</span>
                            <select class="u-sort">
                                <option>{{ get_phrase('Newest first') }}</option>
                                <option>{{ get_phrase('Most popular') }}</option>
                                <option>{{ get_phrase('Price: low to high') }}</option>
                                <option>{{ get_phrase('Price: high to low') }}</option>
                            </select>
                            <div class="u-view-toggle">
                                <button class="u-view-btn active" title="{{ get_phrase('Grid view') }}">
                                    <svg viewBox="0 0 20 20"><rect x="2" y="2" width="7" height="7" rx="1.5"/><rect x="11" y="2" width="7" height="7" rx="1.5"/><rect x="2" y="11" width="7" height="7" rx="1.5"/><rect x="11" y="11" width="7" height="7" rx="1.5"/></svg>
                                </button>
                                <button class="u-view-btn" title="{{ get_phrase('List view') }}">
                                    <svg viewBox="0 0 20 20"><path d="M2 5h16M2 10h16M2 15h16" stroke-linecap="round"/></svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="ugrid">
                        @forelse ($bootcamps as $bootcamp)
                            @include('frontend.default.bootcamp.bootcamp_grid')
                        @empty
                            <div class="u-empty">
                                <div class="u-empty__icon">
                                    <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4" stroke-linecap="round"/></svg>
                                </div>
                                <h3>{{ get_phrase('No programs found') }}</h3>
                                <p>{{ get_phrase('Try adjusting your search or filters to find what you\'re looking for.') }}</p>
                            </div>
                        @endforelse
                    </div>

                    @if ($bootcamps->total() > 0)
                        <div class="u-pages">
                            <nav>{{ $bootcamps->links() }}</nav>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
@push('js')@endpush